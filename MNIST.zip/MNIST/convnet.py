import numpy as np
import gzip

# x = np.random.random((2,8,8)) - 0.5


def ReLU(x):
	'''
	param:
		x : numpy array object
	returns:
		modified x with ReLU function aaplied 
	'''
	x[x<0] = 0
	return x

def nanargmax(a):
	idx = np.argmax(a, axis=None)
	multi_idx = np.unravel_index(idx, a.shape)
	if np.isnan(a[multi_idx]):
		nan_count = np.sum(np.isnan(a))
		# In numpy < 1.8 use idx = np.argsort(a, axis=None)[-nan_count-1]
		idx = np.argpartition(a, -nan_count-1, axis=None)[-nan_count-1]
		multi_idx = np.unravel_index(idx, a.shape)
	return multi_idx

# nanargmax return the indices of the maximum value in that array
def maxpool(X, f, s):
	(l, w, w) = X.shape
	pool = np.zeros((l, (w-f)/s+1,(w-f)/s+1))
	for jj in range(0,l):
		i=0
		while(i<w):
			j=0
			while(j<w):
				pool[jj,i/2,j/2] = np.max(X[jj,i:i+f,j:j+f])
				j+=s
			i+=s
	return pool

# def maxpool(X,w,s):
# 	# size*size is image size
# 	# Image must be square shaped
# 	channels,size,size = X.shape
# 	pool = np.zeros((channels, int(np.ceil(size/(w+s-1))),int(np.ceil(size/(w+s-1))) ))
# 	pool_size = pool.shape[1]
# 	# print(pool.shape)
# 	for channel in range(channels):
# 		ip=0
# 		i = 0
# 		j = 0
# 		while(ip<pool_size):
# 			jp=0
# 			j = 0
# 			while(jp<pool_size):
# 				pool[channel,ip,jp]  = np.max(X[channel,i:i+w,j:j+w])
# 				j += w + s -1
# 				jp = jp+1
# 			i += w + s - 1
# 			ip = ip+1
# 	# print(pool)

# 	return pool



def softmax_cost(out,y):
	eout = np.exp(out, dtype=np.float)#we dont have 128 a typo fixed
	probs = eout/sum(eout)
	
	p = sum(y*probs) #y is the output label [0 0 0 1 0 0 ... ]

	cost = -np.log(p)	## (Only data loss. No regularised loss)
	return cost,probs	


## Returns gradient for all the paramaters in each iteration
def ConvNet(image, label, filt1, filt2, bias1, bias2, theta3, bias3):
	#####################################################################################################################
	#######################################  Feed forward to get all the layers  ########################################
	#####################################################################################################################

	## Calculating first Convolution layer
		
	## l - channel
	## w - size of square image
	## l1 - No. of filters in Conv1
	## l2 - No. of filters in Conv2
	## w1 - size of image after conv1
	## w2 - size of image after conv2

	(l, w, w) = image.shape		
	l1 = len(filt1)
	l2 = len(filt2)
	( _, f, f) = filt1[0].shape

	w1 = w-f+1
	w2 = w1-f+1

	
	conv1 = np.zeros((l1,w1,w1))
	conv2 = np.zeros((l2,w2,w2))  


	for jj in range(0,l1):
		for x in range(0,w1):
			for y in range(0,w1):

				conv1[jj,x,y] = np.sum( image[:,x:x+f,y:y+f] * filt1[jj] ) + bias1[jj]

	ReLU(conv1) 

	## Calculating second Convolution layer

	for jj in range(0,l2):
		for x in range(0,w2):
			for y in range(0,w2):

				conv2[jj,x,y] = np.sum( conv1[:,x:x+f,y:y+f] * filt2[jj] ) + bias2[jj]

	ReLU(conv2) #relu activation

	## Pooled layer with 2*2 size and stride 2,2

	pooled_layer = maxpool(conv2, 2, 2)	

	fc1 = pooled_layer.reshape((int((w2/2))*int((w2/2))*l2,1)) #starting point of fully connected layer
	
	out = theta3.dot(fc1) + bias3	#output of size 10x1
	
	######################################################################################################################
	########################################  Using softmax function to get cost  ########################################
	######################################################################################################################
	
	cost, probs = softmax_cost(out, label)
	if np.argmax(out)==np.argmax(label):
		acc=1
	else:
		acc=0

	
	#######################################################################################################################
	##########################  Backpropagation to get gradient	using chain rule of differentiation  ######################
	#######################################################################################################################
	
	dout = probs - label	#	dL/dout #10x1
	
	dtheta3 = dout.dot(fc1.T) 		##	dL/dtheta3

	dbias3 = sum(dout.T).T.reshape((10,1))		##	dbias3	

	dfc1 = theta3.T.dot(dout)		##	dL/dfc1

	dpool = dfc1.T.reshape((l2, int((w2/2)), int((w2/2))))

	dconv2 = np.zeros((l2, w2, w2))
	
	for jj in range(0,l2):
		i=0
		while(i<w2):
			j=0
			while(j<w2):
				(a,b) = nanargmax(conv2[jj,i:i+2,j:j+2]) ## Getting indexes of maximum value in the array
				dconv2[jj,i+a,j+b] = dpool[jj,int(i/2),int(j/2)]
				j+=2
			i+=2
	
	dconv2[conv2<=0]=0 #ReLU

	dconv1 = np.zeros((l1, w1, w1))
	dfilt2 = {}
	dbias2 = {}
	for xx in range(0,l2):
		dfilt2[xx] = np.zeros((l1,f,f))
		dbias2[xx] = 0

	dfilt1 = {}
	dbias1 = {}
	for xx in range(0,l1):
		dfilt1[xx] = np.zeros((l,f,f))
		dbias1[xx] = 0

	for jj in range(0,l2):
		for x in range(0,w2):
			for y in range(0,w2):
				dfilt2[jj]+=dconv2[jj,x,y]*conv1[:,x:x+f,y:y+f]
				dconv1[:,x:x+f,y:y+f]+=dconv2[jj,x,y]*filt2[jj]
		dbias2[jj] = np.sum(dconv2[jj])
	dconv1[conv1<=0]=0
	for jj in range(0,l1):
		for x in range(0,w1):
			for y in range(0,w1):
				dfilt1[jj]+=dconv1[jj,x,y]*image[:,x:x+f,y:y+f]

		dbias1[jj] = np.sum(dconv1[jj])

	
	return [dfilt1, dfilt2, dbias1, dbias2, dtheta3, dbias3, cost, acc]




def initialize_theta(NUM_OUTPUT, l_in):
	return 0.01*np.random.rand(NUM_OUTPUT, l_in)

def init_kernel(FILTER_SIZE, IMG_DEPTH, distribution='normal'):
	
    # defining standard deviation for the normal distribution of the kernel initialization
    std_shape = FILTER_SIZE*FILTER_SIZE*IMG_DEPTH 
   
    stddev = np.sqrt(1./std_shape)
    kernel_shape = (IMG_DEPTH,FILTER_SIZE,FILTER_SIZE) # kernel shape
    return np.random.normal(loc = 0,scale = stddev,size = kernel_shape) 

## Returns all the trained parameters
def Gradient_Descent(batch, LEARNING_RATE, w, l, MU, filt1, filt2, bias1, bias2, theta3, bias3, cost, acc):
	#	Momentum Gradient Update
	# MU=0.5	
	X = batch[:,0:-1]
	X = X.reshape(len(batch), l, w, w)
	y = batch[:,-1]

	n_correct=0
	cost_ = 0
	batch_size = len(batch)
	dfilt2 = {}
	dfilt1 = {}
	dbias2 = {}
	dbias1 = {}
	v1 = {}
	v2 = {}
	bv1 = {}
	bv2 = {}
	for k in range(0,len(filt2)):
		dfilt2[k] = np.zeros(filt2[0].shape)
		dbias2[k] = 0
		v2[k] = np.zeros(filt2[0].shape)
		bv2[k] = 0
	for k in range(0,len(filt1)):
		dfilt1[k] = np.zeros(filt1[0].shape)
		dbias1[k] = 0
		v1[k] = np.zeros(filt1[0].shape)
		bv1[k] = 0
	dtheta3 = np.zeros(theta3.shape)
	dbias3 = np.zeros(bias3.shape)
	v3 = np.zeros(theta3.shape)
	bv3 = np.zeros(bias3.shape)



	for i in range(0,batch_size):
		
		image = X[i]

		label = np.zeros((theta3.shape[0],1))
		label[int(y[i]),0] = 1
		
		## Fetching gradient for the current parameters
		[dfilt1_, dfilt2_, dbias1_, dbias2_, dtheta3_, dbias3_, curr_cost, acc_] = ConvNet(image, label, filt1, filt2, bias1, bias2, theta3, bias3)
		for j in range(0,len(filt2)):
			dfilt2[j]+=dfilt2_[j]
			dbias2[j]+=dbias2_[j]
		for j in range(0,len(filt1)):
			dfilt1[j]+=dfilt1_[j]
			dbias1[j]+=dbias1_[j]
		dtheta3+=dtheta3_
		dbias3+=dbias3_

		cost_+=curr_cost
		n_correct+=acc_

	for j in range(0,len(filt1)):
		v1[j] = MU*v1[j] -LEARNING_RATE*dfilt1[j]/batch_size
		filt1[j] += v1[j]
		# filt1[j] -= LEARNING_RATE*dfilt1[j]/batch_size
		bv1[j] = MU*bv1[j] -LEARNING_RATE*dbias1[j]/batch_size
		bias1[j] += bv1[j]
	for j in range(0,len(filt2)):
		v2[j] = MU*v2[j] -LEARNING_RATE*dfilt2[j]/batch_size
		filt2[j] += v2[j]
		# filt2[j] += -LEARNING_RATE*dfilt2[j]/batch_size
		bv2[j] = MU*bv2[j] -LEARNING_RATE*dbias2[j]/batch_size
		bias2[j] += bv2[j]
	v3 = MU*v3 - LEARNING_RATE*dtheta3/batch_size
	theta3 += v3
	# theta3 += -LEARNING_RATE*dtheta3/batch_size
	bv3 = MU*bv3 -LEARNING_RATE*dbias3/batch_size
	bias3 += bv3

	cost_ = cost_/batch_size
	cost.append(cost_)
	accuracy = float(n_correct)/batch_size
	acc.append(accuracy)

	return [filt1, filt2, bias1, bias2, theta3, bias3, cost, acc]

## Predict class of each row of matrix X
def predict(image, filt1, filt2, bias1, bias2, theta3, bias3):
	
	## l - channel
	## w - size of square image
	## l1 - No. of filters in Conv1
	## l2 - No. of filters in Conv2
	## w1 - size of image after conv1
	## w2 - size of image after conv2

	(l,w,w)=image.shape
	(l1,f,f) = filt2[0].shape
	l2 = len(filt2)
	w1 = w-f+1
	w2 = w1-f+1
	conv1 = np.zeros((l1,w1,w1))
	conv2 = np.zeros((l2,w2,w2))
	for jj in range(0,l1):
		for x in range(0,w1):
			for y in range(0,w1):
				conv1[jj,x,y] = np.sum(image[:,x:x+f,y:y+f]*filt1[jj])+bias1[jj]
	conv1[conv1<=0] = 0 #relu activation
	## Calculating second Convolution layer
	for jj in range(0,l2):
		for x in range(0,w2):
			for y in range(0,w2):
				conv2[jj,x,y] = np.sum(conv1[:,x:x+f,y:y+f]*filt2[jj])+bias2[jj]
	conv2[conv2<=0] = 0 # relu activation
	## Pooled layer with 2*2 size and stride 2,2
	pooled_layer = maxpool(conv2, 2, 2)	
 	# print(w2)
	fc1 = pooled_layer.reshape(((w2/2)*(w2/2)*l2,1))
	# print(theta3.size, fc1.size, bias3.size)
	out = theta3.dot(fc1) + bias3	#10*1
	eout = np.exp(out, dtype=np.float)
	probs = eout/sum(eout)
	# probs = 1/(1+np.exp(-out))

	# print out
	# print np.argmax(out), np.max(out)
	return np.argmax(probs), np.max(probs)


def extract_data(filename, num_images, IMAGE_WIDTH):
	"""Extract the images into a 4D tensor [image index, y, x, channels].
	Values are rescaled from [0, 255] down to [-0.5, 0.5].
	"""
	print('Extracting', filename)
	with gzip.open(filename) as bytestream:
		bytestream.read(16)
		buf = bytestream.read(IMAGE_WIDTH * IMAGE_WIDTH * num_images)
		data = np.frombuffer(buf, dtype=np.uint8).astype(np.float32) #Interpret a buffer as a 1-dimensional array
		data = data.reshape(num_images, IMAGE_WIDTH*IMAGE_WIDTH)
		return data

def extract_labels(filename, num_images):
	"""Extract the labels into a vector of int64 label IDs.""" 
	print('Extracting', filename)
	with gzip.open(filename) as bytestream:
		bytestream.read(8)
		buf = bytestream.read(1 * num_images)
		labels = np.frombuffer(buf, dtype=np.uint8).astype(np.int64) #Interpret a buffer as a 1-dimensional array
	return labels
