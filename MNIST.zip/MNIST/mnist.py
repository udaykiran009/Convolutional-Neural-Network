
import numpy as np
import gzip
count=0
with gzip.open('train-images-idx3-ubyte.gz','r') as fin:
    for  in fin:
        count = count+1

print(count)