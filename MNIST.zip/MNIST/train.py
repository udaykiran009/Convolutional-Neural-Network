import numpy as np
import scipy.io as sio
import matplotlib.pyplot as plt

from matplotlib import gridspec
import pickle
import time
import random
from convnet import *
from remtime import *

#####################################################################################################################################
################################################## ------ START HERE --------  ######################################################
##################################### ---------- CONVOLUTIONAL NEURAL NETWORK ---------------  ######################################
################ ----ARCHITECTURE PROPOSED : [INPUT - CONV1 - RELU - CONV2 - RELU- MAXPOOL - FC1 - OUT]---- #########################
#####################################################################################################################################


## Hyperparameters
NUM_OUTPUT = 10
LEARNING_RATE = 0.01	#learning rate
IMG_WIDTH = 28
IMG_DEPTH = 1
FILTER_SIZE=4
NUM_FILT1 = 10
NUM_FILT2 =10
BATCH_SIZE = 20
NUM_EPOCHS = 2	 # number of iterations
MU = 0.98

#PICKLE_FILE = 'output.pickle'
PICKLE_FILE = 'trained.pickle'


## Data extracting
m =1000
X = extract_data('t10k-images-idx3-ubyte.gz', m, IMG_WIDTH)
y_dash = extract_labels('t10k-labels-idx1-ubyte.gz', m).reshape(m,1)
image=X[99]
plt.imshow(image.reshape((28,28)))
plt.show()

# print(X.shape)
X-= int(np.mean(X))
X/= int(np.std(X))
print(X)
image=X[99]
plt.imshow(image.reshape((28,28)))
plt.show()
test_data = np.hstack((X,y_dash))

# print(test_data)

print('loaded00000000000000000000000000000000000000')

m =10000
X = extract_data('train-images-idx3-ubyte.gz', m, IMG_WIDTH)
y_dash = extract_labels('train-labels-idx1-ubyte.gz', m).reshape(m,1)
# print (np.mean(X), np.std(X))
X-= int(np.mean(X)) #mean is set to 0

X/= int(np.std(X)) #data is set is normalized to 11
print(np.std(X) , np.mean(X))

train_data = np.hstack((X,y_dash))

np.random.shuffle(train_data)



NUM_IMAGES = train_data.shape[0]
print(NUM_IMAGES, "yahoo")

## Initializing all the parameters
filt1 = {}
filt2 = {}
bias1 = {}
bias2 = {}
for i in range(0,NUM_FILT1):
	filt1[i] = init_kernel(FILTER_SIZE, IMG_DEPTH, distribution='normal')
	bias1[i] = 0
	# v1[i] = 0
for i in range(0,NUM_FILT2):
	filt2[i] = init_kernel(FILTER_SIZE, NUM_FILT1, distribution='normal')
	bias2[i] = 0
	# v2[i] = 0
w1 = IMG_WIDTH-FILTER_SIZE+1
w2 = w1-FILTER_SIZE+1
theta3 = initialize_theta(NUM_OUTPUT, int((w2/2))*int((w2/2))*NUM_FILT2)

bias3 = np.zeros((NUM_OUTPUT,1))
cost = []
acc = []
# pickle_in = open(PICKLE_FILE, 'rb')
# out = pickle.load(pickle_in)

# [filt1, filt2, bias1, bias2, theta3, bias3, cost, acc] = out

xrange = range

print("Learning Rate:"+str(LEARNING_RATE)+", Batch Size:"+str(BATCH_SIZE))

## Training start here

for epoch in range(0,NUM_EPOCHS):
	np.random.shuffle(train_data)
	#xrange gives 20 if number of train images is less than 20 or the number of train images if higher
	batches = [train_data[k:k + BATCH_SIZE] for k in xrange(0, NUM_IMAGES, BATCH_SIZE)] 
	x=0
	for batch in batches:
		#time is started for that batch
		stime = time.time() 

		# LEARNING_RATE =  LEARNING_RATE/(1+epoch/10.0)
		out = Gradient_Descent(batch, LEARNING_RATE, IMG_WIDTH, IMG_DEPTH, MU, filt1, filt2, bias1, bias2, theta3, bias3, cost, acc)
		[filt1, filt2, bias1, bias2, theta3, bias3, cost, acc] = out
		print(filt1[0].shape, filt2[0].shape, "yesss")
		epoch_acc = round(np.sum(acc[int(epoch*NUM_IMAGES/BATCH_SIZE):])/(x+1),2)
		
		per = float(x+1)/len(batches)*100
		print("Epoch:"+str(round(per,2))+"% Of "+str(epoch+1)+"/"+str(NUM_EPOCHS)+", Cost:"+str(cost[-1])+", B.Acc:"+str(acc[-1]*100)+", E.Acc:"+str(epoch_acc))
		
		ftime = time.time()
		deltime = ftime-stime
		remtime = (len(batches)-x-1)*deltime+deltime*len(batches)*(NUM_EPOCHS-epoch-1)
		printTime(remtime)
		x+=1


## saving the trained model parameters
with open(PICKLE_FILE, 'wb') as file:
	pickle.dump(out, file)

## Opening the saved model parameter
pickle_in = open(PICKLE_FILE, 'rb')
out = pickle.load(pickle_in)

[filt1, filt2, bias1, bias2, theta3, bias3, cost, acc] = out


## Plotting the cost and accuracy over different background
gs = gridspec.GridSpec(2, 1, height_ratios=[1, 1]) 
ax0 = plt.subplot(gs[0])
line0, = ax0.plot(cost, color='b')
ax1 = plt.subplot(gs[1], sharex = ax0)
line1, = ax1.plot(acc, color='r', linestyle='--')
plt.setp(ax0.get_xticklabels(), visible=False)
ax0.legend((line0, line1), ('Loss', 'Accuracy'), loc='upper right')
# remove vertical gap between subplots
plt.subplots_adjust(hspace=.0)
plt.show(block=False)

## Computing Test accuracy
X = test_data[:,0:-1]
X = X.reshape(len(test_data), IMG_DEPTH, IMG_WIDTH, IMG_WIDTH)
y = test_data[:,-1]
print('dhjadgfhdsbfk')
print(y.shape)
corr = 0
print("Computing accuracy over test set:")
for i in range(0,len(test_data)):
	image = X[i]
	digit, prob = predict(image, filt1, filt2, bias1, bias2, theta3, bias3)
	print (digit, y[i], prob)
	if digit==y[i]:
		corr+=1
	if (i+1)%int(0.01*len(test_data))==0:
		print(str(float(i+1)/len(test_data)*100)+"% Completed")
test_acc = float(corr)/len(test_data)*100
print("Test Set Accuracy:"+str(test_acc))
